// Bank account logic

public class BankAccount {
    private String owner;
    private double balance;
    private int transactionCount;

    public BankAccount(String owner, double initialBalance) {
        this.owner = owner;
        this.balance = initialBalance;
        this.transactionCount = 0;
    }

    public void deposit(double amount) {
        if (amount <= 0) {
            System.out.println("Deposit amount must be positive");
            return;
        }
        balance += amount;
        transactionCount++;
    }

    public boolean withdraw(double amount) {
        if (amount <= 0) {
            System.out.println("Withdrawal amount must be positive");
            return false;
        }
        if (amount > balance) {
            System.out.println("Insufficient funds");
            return false;
        }
        balance -= amount;
        transactionCount++;
        return true;
    }

    public boolean transfer(BankAccount target, double amount) {
        if (this.withdraw(amount)) {
            target.deposit(amount);
            return true;
        }
        return false;
    }

    public double getBalance() {
        return balance;
    }

    public void printStatement() {
        System.out.println("Account: " + owner);
        System.out.println("Balance: $" + balance);
        System.out.println("Transactions: " + transactionCount);
        System.out.println("---");
    }
}
