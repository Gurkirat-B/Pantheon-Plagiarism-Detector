// Account management logic

public class Account {
    private String holder;
    private double amount;
    private int numTransactions;

    public Account(String holder, double startAmount) {
        this.holder = holder;
        this.amount = startAmount;
        this.numTransactions = 0;
    }

    public void addMoney(double val) {
        if (val <= 0) {
            System.out.println("Deposit amount must be positive");
            return;
        }
        amount += val;
        numTransactions++;
    }

    public boolean takeMoney(double val) {
        if (val <= 0) {
            System.out.println("Withdrawal amount must be positive");
            return false;
        }
        if (val > amount) {
            System.out.println("Insufficient funds");
            return false;
        }
        amount -= val;
        numTransactions++;
        return true;
    }

    public boolean sendMoney(Account dest, double val) {
        if (this.takeMoney(val)) {
            dest.addMoney(val);
            return true;
        }
        return false;
    }

    public double getAmount() {
        return amount;
    }

    public void showDetails() {
        System.out.println("Account: " + holder);
        System.out.println("Balance: $" + amount);
        System.out.println("Transactions: " + numTransactions);
        System.out.println("---");
    }
}
