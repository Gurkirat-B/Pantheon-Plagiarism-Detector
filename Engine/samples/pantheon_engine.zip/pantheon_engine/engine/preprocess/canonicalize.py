from pathlib import Path

ALLOWED_EXTS = {".java", ".c", ".cpp"}

def canonicalize(sub_dir: Path, strip_comments: bool = False) -> Path:
    files = [p for p in sub_dir.rglob("*")
             if p.is_file() and p.suffix.lower() in ALLOWED_EXTS]

    files.sort(key=lambda p: str(p.relative_to(sub_dir)).replace("\\", "/"))

    out = sub_dir / "canonical.txt"
    parts = []
    for f in files:
        rel = str(f.relative_to(sub_dir)).replace("\\", "/")
        parts.append(f"\n<<<FILE:{rel}>>>\n")
        parts.append(f.read_text(encoding="utf-8", errors="ignore"))
        parts.append("\n")

    out.write_text("".join(parts), encoding="utf-8")
    return out