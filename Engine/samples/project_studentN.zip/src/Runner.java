// Student N - Account Management
// Entry point

public class Runner {
    public static void main(String[] args) {
        Account a1 = new Account("Alice", 1000.0);
        Account a2 = new Account("Bob", 500.0);

        a1.addMoney(200.0);
        a1.takeMoney(150.0);
        a2.addMoney(300.0);
        a1.sendMoney(a2, 100.0);

        a1.showDetails();
        a2.showDetails();
    }
}
