// Student M - Bank Account System
// Main entry point

public class Main {
    public static void main(String[] args) {
        BankAccount acc1 = new BankAccount("Alice", 1000.0);
        BankAccount acc2 = new BankAccount("Bob", 500.0);

        acc1.deposit(200.0);
        acc1.withdraw(150.0);
        acc2.deposit(300.0);
        acc1.transfer(acc2, 100.0);

        acc1.printStatement();
        acc2.printStatement();
    }
}
