import shutil
import zipfile
from pathlib import Path

ALLOWED_EXTS = {".java", ".c", ".cpp"}

class UnsafeZipError(Exception):
    pass

def _safe_extract_zip(zip_path: Path, dest: Path, max_files: int = 3000):
    with zipfile.ZipFile(zip_path, "r") as z:
        infos = z.infolist()
        if len(infos) > max_files:
            raise UnsafeZipError("ZIP has too many files")

        dest_resolved = dest.resolve()
        for info in infos:
            out = (dest / info.filename).resolve()
            if not str(out).startswith(str(dest_resolved)):
                raise UnsafeZipError(f"ZIP path traversal detected: {info.filename}")

        z.extractall(dest)

def _prune_non_allowed(root: Path):
    for p in root.rglob("*"):
        if p.is_file() and p.suffix.lower() not in ALLOWED_EXTS:
            try:
                p.unlink()
            except Exception:
                pass

def ingest_to_dir(upload: Path, out_dir: Path) -> Path:
    if out_dir.exists():
        shutil.rmtree(out_dir)
    out_dir.mkdir(parents=True, exist_ok=True)

    upload = upload.resolve()
    suf = upload.suffix.lower()

    if suf == ".zip":
        extracted = out_dir / "extracted"
        extracted.mkdir(parents=True, exist_ok=True)
        _safe_extract_zip(upload, extracted)
        _prune_non_allowed(extracted)
        return out_dir

    if suf not in ALLOWED_EXTS:
        raise ValueError(f"Unsupported file type: {suf}. Allowed: {sorted(ALLOWED_EXTS)}")

    shutil.copy2(upload, out_dir / upload.name)
    return out_dir